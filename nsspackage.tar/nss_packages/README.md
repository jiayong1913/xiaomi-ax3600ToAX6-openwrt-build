# nss-packages
Qualcomm networking packages feed for OpenWrt

These packages provide drivers for wired networking and offloading features for the following SoC-s:
* IPQ807x
* IPQ60xx (Untested)
* IPQ50xx (Untested)

Note that these require kernel patches which are part of the main OpenWrt tree, this is only the package
feed.
